Lucid Launcher. Supply --manifest <url-or-path> for a manifest containing windows-x64. The staged 0.06a release currently contains macOS binaries only.
